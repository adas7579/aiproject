/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ai;

/**
 *
 * @author aNaWorLd
 */
public class hide extends Thread {
    test st;
    public hide(test st)
    {
    this.st=st;
    }
    
    public void run()
    {
        while(true)
        {
            
        }
    }
    
    
}
