/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Games;
import java.io.File;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

public class play extends Thread {

  

String song;
public MediaPlayer play;
    public void run() {
     
    }

    public void stopp() {
    
    }
}
